

class pwm{
  private: 
    float Freq;
    int Pin, selectParameters, dutyCycle;
    String Mode;
  public:
    void setModeOut(int);
    void setParameters(int);
    void setFreq(float);
    void setDC(int);
    int getParameters();
    float getFreq();
    int getDC();
};

void pwm::setModeOut(int _Pin){
  Pin = _Pin;
  pinMode(_Pin, OUTPUT);
}

void pwm::setParameters(int _Parameter){
  selectParameters = _Parameter;
}
void pwm::setFreq(float _Freq){
  Freq = (float)_Freq;
}
void pwm::setDC(int _dutyCycle){
  dutyCycle = _dutyCycle;
}

//
int pwm::getParameters(){
  return selectParameters;
}
float pwm::getFreq(){
  return Freq;
}
int pwm::getDC(){
  return dutyCycle;
}

